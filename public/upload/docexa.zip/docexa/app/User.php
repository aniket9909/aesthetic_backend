<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Doctor;
use App\DoctorAddressDetail;
use App\DoctorSpeciality;
use App\DoctorFee;
use App\Assistantmap;
use App\Skumaster;
use App\Medicalestablishmentsmedicalusermap;
use App\Medicalestablishments;
use URL;
use DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\DoctorsApi;
use App\Http\Controllers\Controller;
use Log;

class User extends Model
{ 

    public function checkRegister($request)
    {
        $rules = [
            'is_user_doctor' => 'required|integer',
            'mobileNo' => 'required|regex:/[0-9]/'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['status' => 'fail', 'msg' => $validator->messages()], 400);
        } else {
            $data = $request->input();
            try {
                if ($data['is_user_doctor'] == 1) {
                    $count = Doctor::where('mobile_no', $data['mobileNo'])->count();
                    if ($count > 0)
                        return response()->json(['status' => "fail", 'msg' => "Opps! Doctor Mobile no is already exists."], 400);
                } else {
                    $count = Doctor::where('mobile_no', $data['mobileNo'])->count();
                    if ($count > 0)
                        return response()->json(['status' => "fail", 'msg' => "Opps! Assistant Mobile no is already exists."], 400);
                }
                $sms = new DoctorsApi();
                $response = $sms->sendOtp($data['mobileNo']);
                return $response;
            } catch (Exception $e) {
                return response()->json(['status' => "fail", 'msg' => "Something went wrong"], 400);
            }
        }
    }

    public function doctorupdate($request)
    {
        $data = $request->input();
        if ($data['step'] == 2) {
            if ($data['is_user_doctor'] == 1) {
                $id = $data['id'];

                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id, 'role' => 'doctor'))->first();
                if (!isset($Medicaldata->medical_user_id)) {
                    return response()->json(['status' => "fail", 'msg' => "Medical establishment didn't found"], 200);
                }
                $Medicaldata->fee = $data['doctor_fee'];
                $Medicaldata->city = $data['doctor_city'];
                $Medicaldata->save();
                $doctor = Doctor::find($Medicaldata->medical_user_id);
                $doctor->medical_registration_no = $data['doctor_mr_no'];
                if (isset($data['doctor_profile_pic']))
                    $doctor->pharmaclient_image = $data['doctor_profile_pic'];
                if (isset($data['doctor_pic']))
                    $doctor->image = $data['doctor_pic'];
                $doctor->speciality_id = $data['speciality_id'];
                $doctor->save();
                $res = new Skumaster();
                $res->createdefaultsku($Medicaldata->id, $data['doctor_fee']);
                return response()->json(['status' => "success", 'doctor' => $this->autologin($Medicaldata->id), 'id' => $id, 'handle' => $_ENV['APP_HANDLE'] . $Medicaldata->handle], 200);
            } else {
                $id = $data['id'];
                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id, 'role' => 'doctor'))->first();
                if (!isset($Medicaldata->medical_user_id)) {
                    return response()->json(['status' => "fail", 'msg' => "Medical establishment didn't found"], 200);
                }
                $Medicaldata->fee = $data['doctor_fee'];
                $Medicaldata->city = $data['doctor_city'];
                $Medicaldata->save();
                $doctor = Doctor::find($Medicaldata->medical_user_id);
                if (isset($data['doctor_profile_pic']))
                    $doctor->pharmaclient_image = $data['doctor_profile_pic'];
                if (isset($data['doctor_pic']))
                    $doctor->image = $data['doctor_pic'];
                $doctor->image = $data['doctor_pic'];
                $doctor->speciality_id = $data['speciality_id'];
                $doctor->save();
                $res = new Skumaster();
                $res->createdefaultsku($Medicaldata->id, $data['doctor_fee']);
                return response()->json(['status' => "success", 'doctor' => $this->autologin($Medicaldata->id), 'id' => $id, 'handle' => $_ENV['APP_HANDLE'] . $Medicaldata->handle], 200);
            }
        } else if ($data['step'] == 3) {
            $id = $data['id'];
            $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("handle" => $data['handle']))->where("medical_establishment_id", "!=", $id)->first();

            if (isset($Medicaldata->handle)) {
                return response()->json(['status' => "fail", 'msg' => "handle is not available", 'id' => $id, 'handle' => $_ENV['APP_HANDLE'] . $Medicaldata->handle], 200);
            }
            if ($data['is_user_doctor'] == 1) {
                $id = $data['id'];
                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id))->first();
                $Medicaldata->handle = $data['handle'];
                $Medicaldata->save();
            } else {
                $id = $data['id'];
                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id))->first();
                $Medicaldata->handle = $data['handle'];
                $Medicaldata->save();
            }
            return response()->json(['status' => "success", 'id' => $id, 'doctor' => $this->autologin($Medicaldata->id), 'handle' => $_ENV['APP_HANDLE'] . $Medicaldata->handle], 200);
        } else if ($data['step'] == 4) {
            if ($data['is_user_doctor'] == 1) {
                $id = $data['id'];
                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id))->first();
                $doctor = Doctor::find($Medicaldata->medical_user_id);
                $doctor->email_id = $data['email'];
                $doctor->password = md5($data['password']);
                $doctor->save();
            } else {
                $id = $data['id'];
                $Medicaldata = Medicalestablishmentsmedicalusermap::where(array("medical_establishment_id" => $id))->first();
                $doctor = Doctor::find($Medicaldata->medical_user_id);
                $doctor->email_id = $data['email'];
                $doctor->password = md5($data['password']);
                $doctor->save();
            }
            $handlearray = $Medicaldata->original;

            $data = [
                'template' => 'welcome_email_to_doctor',
                'handle' => $handlearray['handle'],
                'appointment_id' => ""
            ];
            $c = new Controller();
            $c->sendNotification($data);
            return response()->json(['status' => "success", 'id' => $id, 'doctor' => $this->autologin($Medicaldata->id), 'handle' => $_ENV['APP_HANDLE'] . $Medicaldata->handle], 200);
        }
    }

    public function autologin($esteblishment_user_map_id)
    {

        $tabdata = DB::table('docexa_medical_establishments')
            ->Join('docexa_medical_establishments_medical_user_map', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', '=', 'docexa_medical_establishments.id')
            ->Join('docexa_doctor_master', 'docexa_medical_establishments_medical_user_map.medical_user_id', '=', 'docexa_doctor_master.pharmaclient_id')
            ->select('docexa_doctor_master.image', 'docexa_doctor_master.pharmaclient_name', 'docexa_doctor_master.last_name', 'docexa_doctor_master.pharmaclient_image', 'docexa_medical_establishments_medical_user_map.id', 'docexa_medical_establishments_medical_user_map.handle', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', 'docexa_medical_establishments_medical_user_map.medical_user_id', 'docexa_medical_establishments.address_id')
            ->where('docexa_medical_establishments_medical_user_map.id', $esteblishment_user_map_id)
            ->get()->first();
        if (isset($tabdata->medical_establishment_id)) {
            $response = [
                'esteblishment_id' => $tabdata->medical_establishment_id,
                'esteblishment_user_map_id' => $tabdata->id,
                'medical_user_id' => $tabdata->medical_user_id,
                'handle' => $_ENV['APP_HANDLE'] . $tabdata->handle,
                'first_name' => $tabdata->pharmaclient_name,
                'last_name' => $tabdata->last_name,
                'city' => DoctorAddressDetail::where('id', $tabdata->address_id)->pluck('city')->first(),
                'speciality' => DoctorSpeciality::join('docexa_doctor_speciality_relation', 'docexa_doctor_speciality_relation.speciality_id', '=', 'docexa_speciality_master.speciality_id')->where('docexa_doctor_speciality_relation.pharmaclient_id', $tabdata->medical_user_id)->select('docexa_speciality_master.speciality_name')->pluck('speciality_name')->first(),
                'fee' => (DoctorFee::find($tabdata->medical_user_id)) ? DoctorFee::find($tabdata->medical_user_id)->appt_initial : 0,
                'profilePicture' => (strpos($tabdata->image, 'docexa_default_image') !== false) ? URL::Asset('upload/doctor/profile/' . $tabdata->image) : $tabdata->image
            ];
            return $response;
        } else {
            return [];
        }
    }

    public function login($request)
    {
        $data = $request->input();
        if (isset($data['otp']) && $data['otp'] != '') {
            if ($this->otpverify($data['mobileNo'], $data['otp']) || $data['otp'] == 100) {
                $user = Doctor::where('mobile_no', $data['mobileNo'])->get()->first();
                if (isset($user->pharmaclient_id)) {
                    if($user->user_master_id == 1)
                        $response = $this->logintoaccount($user->pharmaclient_id,'doctor');
                    else{
                        $doctor = DB::table('docexa_doctor_assistant_map')->where('docexa_doctor_assistant_id',$user->pharmaclient_id)->get()->first();
                        $response = $this->logintoaccount($doctor->docexa_doctor_id,'assistant');
                    }
                    return response()->json(['status' => "success", 'data' => $response], 200);
                } else {
                    return response()->json(['status' => "success", 'data' => [], 'msg' => "no record found"], 200);
                }
            } else {
                return response()->json(['status' => "fail", 'msg' => "Opps! OTP incorrect."], 400);
            }
        } else {

            if ($this->emailverify($data['email'], $data['password'])) {
                $doctor = Doctor::where('email_id', $data['email'])->get()->first();
                if (isset($doctor->pharmaclient_id)) {
                    $esteblishment_user_map = Medicalestablishmentsmedicalusermap::where('medical_user_id', $doctor->pharmaclient_id)->get()->first();
                    $tabdata = DB::table('docexa_medical_establishments')
                        ->Join('docexa_medical_establishments_medical_user_map', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', '=', 'docexa_medical_establishments.id')
                        ->Join('docexa_doctor_master', 'docexa_medical_establishments_medical_user_map.medical_user_id', '=', 'docexa_doctor_master.pharmaclient_id')
                        ->select('docexa_doctor_master.image', 'docexa_doctor_master.pharmaclient_name', 'docexa_doctor_master.pharmaclient_image', 'docexa_medical_establishments_medical_user_map.id', 'docexa_medical_establishments_medical_user_map.handle', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', 'docexa_medical_establishments_medical_user_map.medical_user_id', 'docexa_medical_establishments.address_id')
                        ->where('docexa_medical_establishments_medical_user_map.id', $esteblishment_user_map->id)
                        ->get()->first();
                    $response[] = [
                        'esteblishment_id' => $tabdata->medical_establishment_id,
                        'esteblishment_user_map_id' => $tabdata->id,
                        'medical_user_id' => $tabdata->medical_user_id,
                        'handle' => $_ENV['APP_HANDLE'] . $tabdata->handle,
                        'first_name' => $tabdata->pharmaclient_name,
                        'last_name' => '',
                        'type' => 'doctor',
                        'city' => DoctorAddressDetail::where('id', $tabdata->address_id)->pluck('city')->first(),
                        'speciality' => DoctorSpeciality::join('docexa_doctor_speciality_relation', 'docexa_doctor_speciality_relation.speciality_id', '=', 'docexa_speciality_master.speciality_id')->where('docexa_doctor_speciality_relation.pharmaclient_id', $tabdata->medical_user_id)->select('docexa_speciality_master.speciality_name')->pluck('speciality_name')->first(),
                        'fee' => (DoctorFee::find($tabdata->medical_user_id)) ? DoctorFee::find($tabdata->medical_user_id)->appt_initial : 0,
                        'profilePicture' => (strpos($tabdata->image, 'docexa_default_image') !== false) ? URL::Asset('upload/doctor/profile/' . $tabdata->image) : $tabdata->image
                    ];
                    return response()->json(['status' => "success", 'data' => $response], 200);
                } else {
                    return response()->json(['status' => "success", 'data' => [], 'msg' => "no record found"], 200);
                }
            } else {
                return response()->json(['status' => "fail", 'msg' => "Opps! Email ID or password are incorrect."], 400);
            }
        }
    }
    public function logintoaccount($pharmaclient_id,$type)
    {

        $esteblishment_user_map = Medicalestablishmentsmedicalusermap::where('medical_user_id', $pharmaclient_id)->get()->first();
        $tabdata = DB::table('docexa_medical_establishments')
            ->Join('docexa_medical_establishments_medical_user_map', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', '=', 'docexa_medical_establishments.id')
            ->Join('docexa_doctor_master', 'docexa_medical_establishments_medical_user_map.medical_user_id', '=', 'docexa_doctor_master.pharmaclient_id')
            ->select('docexa_doctor_master.image', 'docexa_doctor_master.pharmaclient_name', 'docexa_doctor_master.pharmaclient_image', 'docexa_medical_establishments_medical_user_map.id', 'docexa_medical_establishments_medical_user_map.handle', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', 'docexa_medical_establishments_medical_user_map.medical_user_id', 'docexa_medical_establishments.address_id')
            ->where('docexa_medical_establishments_medical_user_map.id', $esteblishment_user_map->id)
            ->get()->first();
            Log::info('tabdata',['data'=>$esteblishment_user_map->id]);
        $response[] = [
            'esteblishment_id' => $tabdata->medical_establishment_id,
            'esteblishment_user_map_id' => $tabdata->id,
            'medical_user_id' => $tabdata->medical_user_id,
            'handle' => $_ENV['APP_HANDLE'] .  $tabdata->handle,
            'first_name' => $tabdata->pharmaclient_name,
            'last_name' => '',
            'type' => $type,
            'city' => DoctorAddressDetail::where('id', $tabdata->address_id)->pluck('city')->first(),
            'speciality' => DoctorSpeciality::join('docexa_doctor_speciality_relation', 'docexa_doctor_speciality_relation.speciality_id', '=', 'docexa_speciality_master.speciality_id')->where('docexa_doctor_speciality_relation.pharmaclient_id', $tabdata->medical_user_id)->select('docexa_speciality_master.speciality_name')->pluck('speciality_name')->first(),
            'fee' => (DoctorFee::find($tabdata->medical_user_id)) ? DoctorFee::find($tabdata->medical_user_id)->appt_initial : 0,
            'profilePicture' => (strpos($tabdata->image, 'docexa_default_image') !== false) ? URL::Asset('upload/doctor/profile/' . $tabdata->image) : $tabdata->image
        ];
        return $response;
    }

    public function saveRegister($request)
    {
        $data = $request->input();
        if ($data['is_user_doctor'] == 1) {
            $doctordata = $data['doctor'][0];
            if ($this->otpverify($doctordata['mobileNo'], $data['otp'])) {
                $doctor = new Doctor;
                $doctor->pharmaclient_name = $doctordata['firstName'];
                $doctor->last_name = $doctordata['lastName'];
                $doctor->mobile_no = $doctordata['mobileNo'];
                $doctor->login_name = $doctordata['mobileNo'];
                $doctor->pharmaclient_image = 'ProfileImages/docexa_default_image.png';
                $doctor->image = 'ProfileImages/docexa_default_image.png';
                $doctor->user_master_id = 1;
                $doctor->save();
                $medical_user_id = $doctor->pharmaclient_id;
                $medical_establishment_id = $this->createMedicalEstablishments($doctordata['firstName'], $doctordata['lastName']);
                $medical_establishment_doc_map_id = $this->createMedicalEstablishmentsUserMap($medical_user_id, $medical_establishment_id, $doctordata['firstName'], $doctordata['lastName']);

                return response()->json(['status' => "success", 'user_map_id' => $medical_establishment_doc_map_id, 'id' => $medical_establishment_id], 200);
            } else {
                return response()->json(['status' => "fail", 'msg' => "Opps! OTP incorrect."], 400);
            }
        } else {
            $doctordata = $data['doctor'][0];
            $assistant = $data['assistant'][0];
            if ($this->otpverify($assistant['mobileNo'], $data['otp'])) {
                $doctor = new Doctor;
                $doctor->pharmaclient_name = $doctordata['firstName'];
                $doctor->last_name = $doctordata['lastName'];
                $doctor->pharmaclient_image = 'ProfileImages/docexa_default_image.png';
                $doctor->image = 'ProfileImages/docexa_default_image.png';
                $doctor->activation_flag = 0;
                $doctor->user_master_id = 1;
                $doctor->save();
                $docexa_doctor_id = $doctor->pharmaclient_id;
                Log::info('register input', ['data' => $doctor]);
                $assitant = new Doctor;
                $assitant->pharmaclient_name = $assistant['firstName'];
                $assitant->last_name = $assistant['lastName'];
                $assitant->mobile_no = $assistant['mobileNo'];
                $assitant->login_name = $assistant['mobileNo'];
                $assitant->pharmaclient_image = 'ProfileImages/docexa_default_image.png';
                $assitant->image = 'ProfileImages/docexa_default_image.png';
                $assitant->user_master_id = 2;
                $assitant->save();
                Log::info('register input', ['data' => $assitant]);
                $docexa_doctor_assistant_id = $assitant->pharmaclient_id;
                $this->createAssistantmap($docexa_doctor_id, $docexa_doctor_assistant_id);
                $medical_establishment_id = $this->createMedicalEstablishments($doctordata['firstName'], $doctordata['lastName']);
                Log::info('register input', ['data' => $medical_establishment_id]);
                $medical_establishment_doc_map_id = $this->createMedicalEstablishmentsUserMap($docexa_doctor_id, $medical_establishment_id, $doctordata['firstName'], $doctordata['lastName'], 'doctor');
                Log::info('register input', ['data' => $medical_establishment_doc_map_id]);
                $medical_establishment_assist_map_id = $this->createMedicalEstablishmentsUserMap($docexa_doctor_assistant_id, $medical_establishment_id, $assistant['firstName'], $assistant['lastName'], 'assistant');
                return response()->json(['status' => "success", 'id' => $medical_establishment_id], 200);
            } else {
                return response()->json(['status' => "fail", 'msg' => "Opps! OTP incorrect."], 400);
            }
        }
    }
    public function destroydoctor($id, $mobileno)
    {
        if ($mobileno != '') {
        $user = Doctor::where('mobile_no', $mobileno)->get()->first();
        if (isset($user->pharmaclient_id)) {
                if($user->user_master_id == 1){
                    $response = $this->logintoaccount($user->pharmaclient_id,'doctor');
                    DB::table('docexa_doctor_master')->where('pharmaclient_id', $user->pharmaclient_id)->delete();
                }else{
                    $doctor = DB::table('docexa_doctor_assistant_map')->where('docexa_doctor_assistant_id',$user->pharmaclient_id)->get()->first();
                    $response = $this->logintoaccount($doctor->docexa_doctor_id,'assistant');
                    DB::table('docexa_doctor_assistant_map')->where('docexa_doctor_assistant_id', $user->pharmaclient_id)->delete();
                    DB::table('docexa_doctor_master')->where('pharmaclient_id', $user->pharmaclient_id)->delete();
                    DB::table('docexa_doctor_master')->where('mobile_no', $doctor->docexa_doctor_id)->delete();
                }
                
                DB::table('docexa_medical_establishments_medical_user_map')->where('id', $response[0]['esteblishment_id'])->delete();
                DB::table('docexa_medical_establishments')->where('id', $response[0]['esteblishment_id'])->delete();
                return response()->json(['status' => 'success'], 200);
                
            }
        }
        
        $tabdata = DB::table('docexa_medical_establishments')
            ->Join('docexa_medical_establishments_medical_user_map', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', '=', 'docexa_medical_establishments.id')
            ->Join('docexa_doctor_master', 'docexa_medical_establishments_medical_user_map.medical_user_id', '=', 'docexa_doctor_master.pharmaclient_id')
            ->select('docexa_medical_establishments_medical_user_map.id', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', 'docexa_medical_establishments_medical_user_map.medical_user_id')
            ->where('docexa_medical_establishments_medical_user_map.id', $id)
            ->get()->first();
        if (isset($tabdata->id)) {
            DB::table('docexa_doctor_master')->where('pharmaclient_id', $tabdata->medical_user_id)->delete();
            DB::table('docexa_medical_establishments_medical_user_map')->where('id', $tabdata->id)->delete();
            DB::table('docexa_medical_establishments')->where('id', $tabdata->medical_establishment_id)->delete();
            return response()->json(['status' => 'success'], 200);
        } else {
            return response()->json(['status' => 'error', 'msg' => "not found"], 400);
        }
    }
    public function getDoctor($id)
    {
        $tabdata = DB::table('docexa_medical_establishments')
            ->Join('docexa_medical_establishments_medical_user_map', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', '=', 'docexa_medical_establishments.id')
            ->Join('docexa_doctor_master', 'docexa_medical_establishments_medical_user_map.medical_user_id', '=', 'docexa_doctor_master.pharmaclient_id')
            ->select('docexa_doctor_master.image', 'docexa_doctor_master.speciality_id', 'docexa_medical_establishments_medical_user_map.fee as map_fee', 'docexa_medical_establishments_medical_user_map.city as map_city', 'docexa_doctor_master.pharmaclient_name', 'docexa_doctor_master.last_name', 'docexa_doctor_master.pharmaclient_image', 'docexa_medical_establishments_medical_user_map.id', 'docexa_medical_establishments_medical_user_map.medical_establishment_id', 'docexa_medical_establishments_medical_user_map.medical_user_id', 'docexa_medical_establishments.address_id')
            ->where('docexa_medical_establishments_medical_user_map.handle', $id)
            ->get()->first();
        //var_dump($data->pharmaclient_id);die;
        if (isset($tabdata->pharmaclient_name)) {
            $data = [
                'esteblishment_id' => $tabdata->medical_establishment_id,
                'esteblishment_user_map_id' => $tabdata->id,
                'medical_user_id' => $tabdata->medical_user_id,
                'first_name' => $tabdata->pharmaclient_name,
                'last_name' => $tabdata->last_name,
                'city' => $tabdata->map_city,
                'speciality' => DoctorSpeciality::where('speciality_id', $tabdata->speciality_id)->select('docexa_speciality_master.speciality_name')->pluck('speciality_name')->first(),
                'fee' => $tabdata->map_fee,
                'profilePicture' => (strpos($tabdata->image, 'docexa_default_image') !== false) ? URL::Asset('upload/doctor/profile/' . $tabdata->image) : $tabdata->image
            ];
            if (isset($_GET['sku_id'])) {
                $skudata = DB::table('docexa_sku_master')
                    ->Join('docexa_esteblishment_user_map_sku_details', 'docexa_esteblishment_user_map_sku_details.sku_id', '=', 'docexa_sku_master.id')
                    ->select('docexa_esteblishment_user_map_sku_details.sku_id', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_esteblishment_user_map_sku_details.fee', 'docexa_esteblishment_user_map_sku_details.booking_type', 'docexa_esteblishment_user_map_sku_details.default_flag')
                    ->where('docexa_esteblishment_user_map_sku_details.user_map_id', $tabdata->id)->where('docexa_esteblishment_user_map_sku_details.sku_id', $_GET['sku_id'])->get();
                if (count($skudata) > 0)
                    return response()->json(['status' => 'success', 'data' => $data, 'sku_details' => $skudata], 200);
                else {
                    return response()->json(['status' => 'success', 'data' => $data], 200);
                }
            } else {
                $skudata = DB::table('docexa_sku_master')
                    ->Join('docexa_esteblishment_user_map_sku_details', 'docexa_esteblishment_user_map_sku_details.sku_id', '=', 'docexa_sku_master.id')
                    ->select('docexa_esteblishment_user_map_sku_details.sku_id', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_esteblishment_user_map_sku_details.fee', 'docexa_esteblishment_user_map_sku_details.booking_type', 'docexa_esteblishment_user_map_sku_details.default_flag')
                    ->where('docexa_esteblishment_user_map_sku_details.user_map_id', $tabdata->id)->get();
                if (count($skudata) > 0)
                    return response()->json(['status' => 'success', 'data' => $data, 'sku_details' => $skudata], 200);
                else {
                    return response()->json(['status' => 'success', 'data' => $data], 200);
                }
            }
            // return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'error', 'msg' => 'No record found'], 200);
        }
    }

    public function createMedicalEstablishments($firstName, $lastName)
    {
        $Medicalestablishments = new Medicalestablishments;
        $Medicalestablishments->name = $firstName . " " . $lastName;
        $Medicalestablishments->active = 1;
        $Medicalestablishments->address_id = 1;
        $Medicalestablishments->save();
        return $Medicalestablishments->id;
    }

    public function createMedicalEstablishmentsUserMap($medical_user_id, $medical_establishment_id, $firstName, $lastName, $role = 'doctor')
    {
        $Medicalestablishmentsmedicalusermap = new Medicalestablishmentsmedicalusermap;
        $Medicalestablishmentsmedicalusermap->medical_user_id = $medical_user_id;
        $Medicalestablishmentsmedicalusermap->medical_establishment_id = $medical_establishment_id;
        $Medicalestablishmentsmedicalusermap->is_primary = 1;
        $Medicalestablishmentsmedicalusermap->role = $role;
        $Medicalestablishmentsmedicalusermap->handle = $this->uniqueHandle($firstName, $lastName);
        $Medicalestablishmentsmedicalusermap->save();
        return $Medicalestablishmentsmedicalusermap->id;
    }

    public function uniqueHandle($firstName, $lastName)
    {
        $cominedstring = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '', $firstName . "" . $lastName)));
        $count = Medicalestablishmentsmedicalusermap::where('handle', 'regexp', 'dr' . $cominedstring . '[_0-9]*$')->count();
        if ($count >= 1) {
            $num = ++$count;             // Increment $usercnt by 1
            $handle = 'dr' . $cominedstring . $num;  // Add number to username
        } else {
            $handle = 'dr' . $cominedstring;
        }
        return $handle;
    }

    public function createAssistantmap($docexa_doctor_id, $docexa_doctor_assistant_id)
    {
        $assitantmap = new Assistantmap;
        $assitantmap->docexa_doctor_id = $docexa_doctor_id;
        $assitantmap->docexa_doctor_assistant_id = $docexa_doctor_assistant_id;
        $assitantmap->save();
    }

    public function otpverify($mobileno, $otp)
    {
        $count = Otp::where('phone_no', '=', $mobileno)->where('otp', '=', $otp)->count();
        if ($count >= 1) {
            return true;
        } else {
            return false;
        }
    }
    public function emailverify($email, $password)
    {
        $count = Doctor::where('email_id', '=', $email)->where('password', '=', md5($password))->count();
        if ($count >= 1) {
            return true;
        } else {
            return false;
        }
    }
}
