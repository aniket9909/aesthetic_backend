<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class Medicalestablishmentsmedicalusermap extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    
    protected $table = 'docexa_medical_establishments_medical_user_map';
    protected $primaryKey = 'id';
    
}
