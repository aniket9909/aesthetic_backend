<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\AppointmentDetails;

class Payment extends Model {

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'docexa_appointment_transcation_master';
    protected $primaryKey = 'id';

    public function createpayment($bookingID) {
        $res = new AppointmentDetails();
        $appointment_data = $res->getappointment(null, $bookingID);
        if (!isset($appointment_data['appointment'][0])) {
            $data['msg'] = "Booking ID not matched";
            return $data;
        } else {
            $appointment_data = $appointment_data['appointment'][0];
            $data['key'] = "MTHxR83B";
            $salt = "jKt5ITcxzH";
           $data['baseurl'] = "https://sandboxsecure.payu.in/_payment";
        //    $data['baseurl'] = "https://secure.payu.in/_payment";   
            $data['amount'] = $appointment_data->cost;
            $data['productinfo'] = $bookingID;
            $data['firstname'] = $appointment_data->patient_name;
            $data['phone'] = $appointment_data->mobile_no;
            $data['email'] = $appointment_data->email;
            $data['txnid'] = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
            $string = $data['key'].'|'.$data['txnid'].'|'.$data['amount'].'|'.$data['productinfo'].'|'.$data['firstname'].'|'.$data['email'].'|||||||||||'.$salt;
            
            $data['hash'] = strtolower(hash('sha512',$string));
            $data['surl'] = 'https://apidev.docexa.com/v1/payment/'.$bookingID.'/success';
            $data['furl'] = 'https://apidev.docexa.com/v1/payment/'.$bookingID.'/fail';
            $data['service_provider'] = 'payu_paisa';
            $data['payment_url'] = 'https://apidev.docexa.com/v1/payment/'.$bookingID.'/pay';


            return $data;
        }
    }
    public function createpaymentv2($bookingID) {
        $res = new AppointmentDetails();
        $appointment_data = $res->getappointmentv3(null, $bookingID);
        if (!isset($appointment_data['appointment'][0])) {
            $data['msg'] = "Booking ID not matched";
            return $data;
        } else {
            $appointment_data = $appointment_data['appointment'][0];
            $data['key'] = "MTHxR83B";
            $salt = "jKt5ITcxzH";
            $data['baseurl'] = "https://sandboxsecure.payu.in/_payment";
            
            $data['amount'] = $appointment_data->cost;
            $data['productinfo'] = $bookingID;
            $data['firstname'] = $appointment_data->patient_name;
            $data['phone'] = $appointment_data->mobile_no;
            $data['email'] = $appointment_data->email;
            $data['txnid'] = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
            $string = $data['key'].'|'.$data['txnid'].'|'.$data['amount'].'|'.$data['productinfo'].'|'.$data['firstname'].'|'.$data['email'].'|||||||||||'.$salt;
            
            $data['hash'] = strtolower(hash('sha512',$string));
            $data['surl'] = 'https://apidev.docexa.com/v2/payment/'.$bookingID.'/success';
            $data['furl'] = 'https://apidev.docexa.com/v2/payment/'.$bookingID.'/fail';
            $data['service_provider'] = 'payu_paisa';
            $data['payment_url'] = 'https://apidev.docexa.com/v2/payment/'.$bookingID.'/pay';


            return $data;
        }
    }


    function getCallbackUrl() {
        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . 'response.php';
    }

}
