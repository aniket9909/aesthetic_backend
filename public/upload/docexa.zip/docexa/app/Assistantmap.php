<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class Assistantmap extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    
    protected $table = 'docexa_doctor_assistant_map';
    protected $primaryKey = 'id';
    
}
