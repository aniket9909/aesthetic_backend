<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class Medicalestablishments extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    
    protected $table = 'docexa_medical_establishments';
    protected $primaryKey = 'id';
    
}
