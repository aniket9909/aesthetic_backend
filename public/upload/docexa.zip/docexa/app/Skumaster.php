<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class Skumaster extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    
    protected $table = 'docexa_sku_master';
    protected $primaryKey = 'id';
    public function getskudetails($esteblishmentUserMapID) {
        
            try {
                if ($esteblishmentUserMapID == '') {
                     return response()->json(['status' => "fail", 'msg' => "Opps! esteblishment user map id not found."], 400);
                }
                
                $data = DB::table('docexa_sku_master')
                        ->Join('docexa_esteblishment_user_map_sku_details', 'docexa_esteblishment_user_map_sku_details.sku_id', '=', 'docexa_sku_master.id')
                        ->where('docexa_esteblishment_user_map_sku_details.user_map_id', $esteblishmentUserMapID)->get();
        return response()->json(['status' => "success", 'data' => $data], 200);
            } catch (Exception $e) {
                return response()->json(['status' => "fail", 'msg' => "Something went wrong"], 400);
            }
    }
    public function getskudetailsbyid($user_map_id,$sku_id) {
        $data = DB::table('docexa_sku_master')
                        ->Join('docexa_esteblishment_user_map_sku_details', 'docexa_esteblishment_user_map_sku_details.sku_id', '=', 'docexa_sku_master.id')
                        
                        ->where('docexa_esteblishment_user_map_sku_details.sku_id', $sku_id)
                        ->where('docexa_esteblishment_user_map_sku_details.user_map_id', $user_map_id)->get()->first();
       return $data;
    }
      public function createdefaultsku($esteblishmentUserMapID,$fee) {
       DB::table('docexa_esteblishment_user_map_sku_details')->insert(['user_map_id' => $esteblishmentUserMapID, 'booking_type' => 'Online Consultation','sku_id'=>1,'fee'=>$fee]);
       DB::table('docexa_esteblishment_user_map_sku_details')->insert(['user_map_id' => $esteblishmentUserMapID, 'booking_type' => 'In clinic Consultation','sku_id'=>2,'fee'=>'4100']);
       DB::table('docexa_esteblishment_user_map_sku_details')->insert(['user_map_id' => $esteblishmentUserMapID, 'booking_type' => 'Online Consultation','sku_id'=>3,'fee'=>'100']);
       
    }
}