<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Skumaster;
use App\Payment;
use App\Patientmasterphizer;
use App\Http\Controllers\Controller;
use App\Jobs\updateStatus;
use Carbon\Carbon;
class AppointmentDetails extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'docexa_patient_booking_details';
    protected $primaryKey = 'id';
    public function getappointmentv2($request, $bookingID = 0)
    {
        //var_dump($bookingID,$bookingID != 0);die;
        if ($bookingID != 0 || $request == null) {
            $tabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_sku_master.id as sku_id', 'docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.email_id as email', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.bookingidmd5', $bookingID)
                ->groupBy('docexa_patient_booking_details.bookingidmd5')
                ->get();
            $timingArray = DB::table('docexa_appointment_sku_details')->whereRaw("md5(booking_id) = ?", [$bookingID])->get();
            $data = [];
            foreach ($timingArray as $timing) {
                $data[] = ['start_booking_time' => $timing->start_booking_time, 'end_booking_time' => $timing->end_booking_time];
            }

            if (count($tabdata) > 0) {
                $tabdata[0]->timing_details = $data;
                $response = [
                    'appointment' => $tabdata[0]
                ];
            } else {
                $response = [
                    'appointment' => $tabdata[0],
                    'msg' => "no record found"
                ];
            }

            return $response;
        } else {
            $data = $request->input();
            $unscheduletabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->where('docexa_patient_booking_details.date', null)
                ->whereIn('docexa_patient_booking_details.status',[1])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_patient_booking_details.created_date')
                ->get();
            $todaystabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->where('docexa_patient_booking_details.date', '=', date('Y-m-d'))
                ->where('docexa_patient_booking_details.status', '!=', 3)
                ->where('docexa_patient_booking_details.status', '!=', 6)
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_patient_booking_details.start_time')
                ->get();
            
            $pasttabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
              //  ->whereNotNull('docexa_patient_booking_details.date')
                ->whereIn('docexa_patient_booking_details.status',[4,3,6])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
               ->latest('docexa_patient_booking_details.created_date')
                ->get();
            $upcomingtabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->whereNotNull('docexa_patient_booking_details.date')
                ->whereIn('docexa_patient_booking_details.status',[2,5])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_appointment_sku_details.start_booking_time')
                ->get();
               
                
            $response = [
                'unscheduleappointment' => $unscheduletabdata,
                'todayappointment' => $todaystabdata,
                'pastappointment' => $pasttabdata,
                'upcomingappointment' => $upcomingtabdata
            ];
            return $response;
        }
    }
    public function getappointment($request, $bookingID = 0)
    {
        //var_dump($bookingID,$bookingID != 0);die;
        if ($bookingID != 0 || $request == null) {
            $tabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.patient_id','docexa_patient_booking_details.booking_id as book_id','docexa_patient_booking_details.doctor_id','docexa_sku_master.id as sku_id', 'docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.email_id as email', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.bookingidmd5', $bookingID)
                ->groupBy('docexa_patient_booking_details.bookingidmd5')
                ->get();
            $timingArray = DB::table('docexa_appointment_sku_details')->whereRaw("md5(booking_id) = ?", [$bookingID])->get();
            $data = [];
            foreach ($timingArray as $timing) {
                $data[] = ['start_booking_time' => $timing->start_booking_time, 'end_booking_time' => $timing->end_booking_time];
            }

            if (count($tabdata) > 0) {
                $tabdata[0]->timing_details = $data;
                $response = [
                    'appointment' => $tabdata
                ];
            } else {
                $response = [
                    'appointment' => $tabdata,
                    'msg' => "no record found"
                ];
            }

            return $response;
        } else {
            $data = $request->input();
            $unscheduletabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->where('docexa_patient_booking_details.date', null)
                ->whereIn('docexa_patient_booking_details.status',[1])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_patient_booking_details.created_date')
                ->get();
            $todaystabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->where('docexa_patient_booking_details.date', '=', date('Y-m-d'))
                ->where('docexa_patient_booking_details.status', '!=', 3)
                ->where('docexa_patient_booking_details.status', '!=', 6)
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_patient_booking_details.start_time')
                ->get();
            
            $pasttabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
               // ->whereNotNull('docexa_patient_booking_details.date')
                ->whereIn('docexa_patient_booking_details.status',[4,3,6])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
               ->latest('docexa_patient_booking_details.created_date')
                ->get();
            $upcomingtabdata = DB::table('docexa_patient_booking_details')
                ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
                ->Join('docexa_patient_details', 'docexa_patient_details.patient_id', '=', 'docexa_patient_booking_details.patient_id')
                ->Join('docexa_sku_master', 'docexa_sku_master.id', '=', 'docexa_appointment_sku_details.esteblishment_user_map_sku_id')
                ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details.status')
                ->Join('docexa_medical_establishments_medical_user_map', 'docexa_patient_booking_details.user_map_id', '=', 'docexa_medical_establishments_medical_user_map.id')
                ->select('docexa_patient_booking_details.cancellation_reason as reason', 'docexa_patient_booking_details.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details.status', 'docexa_patient_booking_details.schedule_remark', 'docexa_appointment_sku_details.booking_type', 'docexa_sku_master.title', 'docexa_sku_master.description', 'docexa_patient_booking_details.bookingidmd5 as booking_id', 'docexa_patient_booking_details.created_date', 'docexa_patient_booking_details.date', 'docexa_patient_booking_details.start_time', 'docexa_patient_details.patient_name', 'docexa_patient_details.mobile_no', 'docexa_patient_booking_details.cost')
                ->selectRaw('+91 as country_code')
                ->selectRaw("concat('".$_ENV['APP_HANDLE']."',docexa_medical_establishments_medical_user_map.handle) as handle")
                ->where('docexa_patient_booking_details.user_map_id', $data['user_map_id'])
                ->whereNotNull('docexa_patient_booking_details.date')
                ->whereIn('docexa_patient_booking_details.status',[2,5])
                ->whereNotNull('docexa_patient_booking_details.credit_history_id')
                ->latest('docexa_appointment_sku_details.start_booking_time')
                ->get();
               
                
            $response = [
                'unscheduleappointment' => $unscheduletabdata,
                'todayappointment' => $todaystabdata,
                'pastappointment' => $pasttabdata,
                'upcomingappointment' => $upcomingtabdata
            ];
            return $response;
        }
    }
    public function getappointmentv3($request, $bookingID = 0)
    {
        $tabdata = DB::table('docexa_patient_booking_details_phizer')
            ->Join('docexa_patient_details_phizer', 'docexa_patient_details_phizer.patient_id', '=', 'docexa_patient_booking_details_phizer.patient_id')
            ->Join('docexa_appointment_status_master', 'docexa_appointment_status_master.id', '=', 'docexa_patient_booking_details_phizer.status')
            ->select('docexa_patient_booking_details_phizer.location', 'docexa_patient_booking_details_phizer.latlong', 'docexa_patient_booking_details_phizer.cancellation_reason as reason', 'docexa_patient_booking_details_phizer.status', 'docexa_appointment_status_master.status_text', 'docexa_patient_booking_details_phizer.schedule_remark', 'docexa_patient_booking_details_phizer.bookingidmd5 as booking_id', 'docexa_patient_booking_details_phizer.created_date', 'docexa_patient_booking_details_phizer.date', 'docexa_patient_booking_details_phizer.start_time', 'docexa_patient_details_phizer.patient_name', 'docexa_patient_details_phizer.email_id as email', 'docexa_patient_details_phizer.mobile_no', 'docexa_patient_booking_details_phizer.cost')
            ->selectRaw('+91 as country_code')
            ->where('docexa_patient_booking_details_phizer.bookingidmd5', $bookingID)
            ->groupBy('docexa_patient_booking_details_phizer.bookingidmd5')
            ->get();

        if (count($tabdata) > 0) {
            $response = [
                'appointment' => $tabdata
            ];
        } else {
            $response = [
                'appointment' => $tabdata,
                'msg' => "no record found"
            ];
        }

        return $response;
    }
    public function getallslot($user_map_id, $date = null)
    {
        if ($date == null) {
            $date = date('Y-m-d');
        }
        $response = DB::table('docexa_patient_booking_details')
            ->Join('docexa_appointment_sku_details', 'docexa_patient_booking_details.booking_id', '=', 'docexa_appointment_sku_details.booking_id')
            ->selectRaw('date_format(docexa_appointment_sku_details.start_booking_time,"%H:%i") as start_booking_time,date_format(docexa_appointment_sku_details.end_booking_time,"%H:%i") as end_booking_time')
            ->where('docexa_patient_booking_details.user_map_id', $user_map_id)
            ->where('docexa_patient_booking_details.date', '=', $date)
            ->get();

        return $response;
    }
    public function scheduleappointmentv2($request)
    {

        $data = $request->input();

        if ($data['scheduletimestamp'] != '') {
            $date = date('Y-m-d', strtotime($data['scheduletimestamp']));
            $time = date('H:i', strtotime($data['scheduletimestamp']));
            $data['scheduletimestamp'] = date('Y-m-d H:i:s', strtotime($data['scheduletimestamp']));
            $end_booking_time = date('Y-m-d H:i:s', strtotime('+' . $data['slot_size'] . ' minutes', strtotime($data['scheduletimestamp'])));
        } else {
            $data['scheduletimestamp'] = null;
            $end_booking_time = null;
            $date = null;
            $time = null;
        }
        if ($data['slot_size'] == '')
            $data['slot_size'] = 0;
        DB::table('docexa_patient_booking_details')->where('bookingidmd5', $data['bookingID'])->limit(1)->update(array('cancellation_reason' => $data['remark'], 'status' => $data['status'], 'date' => $date, 'start_time' => $time));
        $booking_id = DB::table('docexa_patient_booking_details')->where('bookingidmd5', $data['bookingID'])->get()->first()->booking_id;
        DB::table('docexa_appointment_sku_details')->where('booking_id', $booking_id)->limit(1)->update(array('start_booking_time' => $data['scheduletimestamp'], 'end_booking_time' => $end_booking_time, 'slot_size' => $data['slot_size']));
        $tabdata = $this->getappointmentv2(null, $data['bookingID']);
        $urlArray = parse_url($tabdata['appointment']->handle, PHP_URL_PATH);
        $segments = explode('/', $urlArray);
        $numSegments = count($segments);
        $currentSegment = $segments[$numSegments - 1];
        // var_dump($currentSegment);die;
        $c = new Controller();
        if ($data['status'] == 2) { 
            $start = Carbon::parse($data['scheduletimestamp']);
            $start->setTimezone('Asia/Kolkata');
            $us = new updateStatus($data['bookingID']);
            $us->apptID();
            dispatch((new updateStatus($data['bookingID']))->delay($start->addMinutes(2)));
            $notificationdata = [
                'template' => 'appointment_accepted_notifier',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            
        } else if ($data['status'] == 4) {
            $notificationdata = [
                'template' => 'doc_appointment_completed_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_completed_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 3) {
            $notificationdata = [
                'template' => 'doc_appointment_cancelled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_cancelled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 7) {
            $start = Carbon::parse($data['scheduletimestamp']);
            $start->setTimezone('Asia/Kolkata');
            $us = new updateStatus($data['bookingID']);
            $us->apptID();
            dispatch((new updateStatus($data['bookingID']))->delay($start->addMinutes(2)));    
            $notificationdata = [
                'template' => 'appointment_rescheduled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 6) {
            $notificationdata = [
                'template' => 'doctor_appointment_request_rejected_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_request_rejected_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        }
        return $tabdata;
    }
    public function scheduleappointment($request)
    {
        $data = $request->input();

        if ($data['scheduletimestamp'] != '') {
            $date = date('Y-m-d', strtotime($data['scheduletimestamp']));
            $time = date('H:i', strtotime($data['scheduletimestamp']));
            $data['scheduletimestamp'] = date('Y-m-d H:i:s', strtotime($data['scheduletimestamp']));
            $end_booking_time = date('Y-m-d H:i:s', strtotime('+' . $data['slot_size'] . ' minutes', strtotime($data['scheduletimestamp'])));
        } else {
            $data['scheduletimestamp'] = null;
            $end_booking_time = null;
            $date = null;
            $time = null;
        }
        if ($data['slot_size'] == '')
            $data['slot_size'] = 0;
        DB::table('docexa_patient_booking_details')->where('bookingidmd5', $data['bookingID'])->limit(1)->update(array('cancellation_reason' => $data['remark'], 'status' => $data['status'], 'date' => $date, 'start_time' => $time));
        $booking_id = DB::table('docexa_patient_booking_details')->where('bookingidmd5', $data['bookingID'])->get()->first()->booking_id;
        DB::table('docexa_appointment_sku_details')->where('booking_id', $booking_id)->limit(1)->update(array('start_booking_time' => $data['scheduletimestamp'], 'end_booking_time' => $end_booking_time, 'slot_size' => $data['slot_size']));
        $tabdata = $this->getappointment(null, $data['bookingID']);

        $urlArray = parse_url($tabdata['appointment'][0]->handle, PHP_URL_PATH);
        $segments = explode('/', $urlArray);
        $numSegments = count($segments);
        $currentSegment = $segments[$numSegments - 1];
        // var_dump($currentSegment);die;
        $c = new Controller();
        if ($data['status'] == 2) { 
            $start = Carbon::parse($data['scheduletimestamp']);
            $start->setTimezone('Asia/Kolkata');
            $us = new updateStatus($data['bookingID']);
            $us->apptID();
            dispatch((new updateStatus($data['bookingID']))->delay($start->addMinutes(2)));
            $notificationdata = [
                'template' => 'appointment_accepted_notifier',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            
        } else if ($data['status'] == 4) {
            $notificationdata = [
                'template' => 'doc_appointment_completed_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_completed_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 3) {
            $notificationdata = [
                'template' => 'doc_appointment_cancelled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_cancelled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 7) {
            $start = Carbon::parse($data['scheduletimestamp']);
            $start->setTimezone('Asia/Kolkata');
            $us = new updateStatus($data['bookingID']);
            $us->apptID();
            dispatch((new updateStatus($data['bookingID']))->delay($start->addMinutes(2)));    
            $notificationdata = [
                'template' => 'appointment_rescheduled_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        } else if ($data['status'] == 6) {
            $notificationdata = [
                'template' => 'doctor_appointment_request_rejected_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
            $notificationdata = [
                'template' => 'patient_appointment_request_rejected_intimation',
                'handle' => $currentSegment,
                'appointment_id' => $data['bookingID']
            ];
            $c->sendNotification($notificationdata);
        }
        //var_dump(json_encode($data));die;


        return $tabdata;
    }

    public function createappointment($request)
    {
        $data = $request->input();
        //var_dump($data);die;
        if (!isset($data['age'])) {
            $data['age'] = 0;
        }
        $medicaldata = Medicalestablishmentsmedicalusermap::find($data['user_map_id'])->get()->first();
        $check = Patientmaster::where('mobile_no', $data['patient_mobile_no'])->first();

        if (isset($check->patient_id)) {
            $patientdata = $check;
        } else {
            $patientdata = new Patientmaster();
            $patientdata->patient_name = $data['patient_name'];
            $patientdata->email_id = $data['email'];
            $patientdata->mobile_no = $data['patient_mobile_no'];
            $patientdata->username = $data['patient_mobile_no'];
            $patientdata->save();
        }
        $skuobj = new Skumaster();
        $skudata = $skuobj->getskudetailsbyid($data['user_map_id'], $data['sku_id']);
        //return ['payment'=>$skudata];
        $id = DB::table('docexa_patient_booking_details')->insertGetId(['status' => 1, 'schedule_remark' => $data['schedule_remark'], 'created_date' => date('Y-m-d H:i:s'), 'user_map_id' => $data['user_map_id'], 'cost' => $skudata->fee, 'age' => $data['age'], 'patient_id' => $patientdata->patient_id, 'doctor_id' => $medicaldata->medical_user_id]);
        DB::table('docexa_appointment_sku_details')->insertGetId(['created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s'), 'booking_id' => $id, 'esteblishment_user_map_sku_id' => $data['sku_id'], 'cost' => $skudata->fee, 'payable_price' => $skudata->fee, 'discount' => 0, 'booking_type' => $skudata->booking_type]);
        DB::table('docexa_patient_booking_details')->where('booking_id', $id)->limit(1)->update(array('bookingidmd5' => md5($id)));
        $tabdata = $this->getappointment(null, md5($id));
        $res = new payment();
        $paymentdata = $res->createpayment(md5($id));
        return ['appointment' => $tabdata['appointment'], 'payment' => $paymentdata];
    }
    public function createappointmentv2($request)
    {
        $data = $request->input();
        $data['age'] = 0;
        if (!isset($data['location'])) {
            $data['location'] =  'NA';
        }
        if (!isset($data['latlong'])) {
            $data['latlong'] =  'NA';
        }
        if (!isset($data['city'])) {
            $data['city'] =  'NA';
        }
        $check = Patientmasterphizer::where('mobile_no', $data['patient_mobile_no'])->first();

        if (isset($check->patient_id)) {
            $patientdata = $check;
        } else {
            $patientdata = new Patientmasterphizer();
            $patientdata->patient_name = $data['patient_name'];
            $patientdata->city = $data['city'];
            $patientdata->mobile_no = $data['patient_mobile_no'];
            $patientdata->username = $data['patient_mobile_no'];
            $patientdata->save();
        }
        $id = DB::table('docexa_patient_booking_details_phizer')->insertGetId(['status' => 1, 'created_date' => date('Y-m-d H:i:s'), 'cost' => '100', 'latlong' => $data['latlong'], 'location' => $data['location'], 'age' => $data['age'], 'patient_id' => $patientdata->patient_id, 'doctor_id' => null]);
        DB::table('docexa_patient_booking_details_phizer')->where('booking_id', $id)->limit(1)->update(array('bookingidmd5' => md5($id)));
        $tabdata = $this->getappointment(null, md5($id));
        $res = new payment();
        $paymentdata = $res->createpaymentv2(md5($id));
        return ['appointment' => $tabdata['appointment'], 'payment' => $paymentdata];
    }
    public function updatestatus($appt_id)
    {
    error_log("handle process");
        DB::table('docexa_patient_booking_details')->where('bookingidmd5', $appt_id)->limit(1)->update(array('status' => 5));

    }
}
