<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Doctor extends Model {

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'docexa_doctor_master';
    protected $primaryKey = 'pharmaclient_id';
    protected $fillable = [
        'pharmaclient_name', 'email_id',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];


}
