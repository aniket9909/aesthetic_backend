<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class Patientmaster extends Model
{
    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    
    protected $table = 'docexa_patient_details';
    protected $primaryKey = 'patient_id';
    
}
