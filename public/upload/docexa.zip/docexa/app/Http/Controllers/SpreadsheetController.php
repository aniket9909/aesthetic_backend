<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Google_Client; 
use Google_Service_Drive;
use Google_Service_Sheets;
use Google_Service_Sheets_ValueRange;
class SpreadsheetController extends Controller

{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        define('STDIN',fopen("php://stdin","r"));

        //
    }
    public function oauth2callback()
{
}
    public function getClient()
{
    $client = new Google_Client();
    $client->setRedirectUri('https://' . $_SERVER['HTTP_HOST'] . '/v3/oauth2callback');
    $client->setApplicationName('Google Sheets API PHP Quickstart');
    $client->setScopes(Google_Service_Sheets::SPREADSHEETS);
    $client->setAuthConfig(storage_path('credentials.json'));
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    // Load previously authorized token from a file, if it exists.
    // The file token.json stores the user's access and refresh tokens, and is
    // created automatically when the authorization flow completes for the first
    // time.
    $tokenPath = storage_path('logs/token.json');
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        // Refresh the token if possible, else fetch a new one.
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
        } else {
            // Request authorization from the user.
            $authUrl = $client->createAuthUrl();
            echo '<script>window.open("'.$authUrl.'","_blank")</script>';
            print 'Enter verification code: ';
            $authCode = trim("4/0AY0e-g5eEq7Yf0iwFHBm3GvJEaXHHj_EbUw5wgFgxH4Mq2KRoNp3ikFbDM4k9UpN4UeVDw");

            // Exchange authorization code for an access token.
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);

            // Check to see if there was an error.
            if (array_key_exists('error', $accessToken)) {
                throw new Exception(join(', ', $accessToken));
            }
        }
        // Save the token to a file.
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0777, true);
        }
        file_put_contents($tokenPath, json_encode($client->getAccessToken()));
    }
    return $client;
}
public function masterdata($location='NA',$latlong='NA',$name='NA',$mobile_no='NA',$created_date,$amount=0){
$client = $this->getClient();
$service = new Google_Service_Sheets($client);

// Prints the names and majors of students in a sample spreadsheet:
// https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
$spreadsheetId = '1WvnMh8UIfjYHfVdNKsCIy7rlhzxMhPXAB7KO1U-7HPU';
$range = "Sheet1";
$valueRange= new Google_Service_Sheets_ValueRange();
$valueRange->setValues(["values" => [$location,$latlong,$name,$mobile_no,$created_date,$amount]]); 
$conf = ["valueInputOption" => "RAW"];
$service->spreadsheets_values->append($spreadsheetId, $range, $valueRange, $conf);
/*
$range = 'Sheet1';
$response = $service->spreadsheets_values->put($spreadsheetId, $range);
$values = $response->getValues();

if (empty($values)) {
    print "No data found.\n";
} else {
    var_dump($values);

}
*/
}
}
