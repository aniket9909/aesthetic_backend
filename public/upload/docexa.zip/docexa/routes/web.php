<?php

use Illuminate\Http\Request;
use Illuminate\Http\Response;

/** @var \Laravel\Lumen\Routing\Router $router */
/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It is a breeze. Simply tell Lumen the URIs it should respond to
  | and give it the Closure to call when that URI is requested.
  |
 */

$router->get('/', function () use ($router) {
    return $router->app->version();
});
$router->get('admin/log', [
    'middleware' => 'log'
]);
$router->get('testjob', 'JobApi@index');
$router->group(['prefix' => 'v3'], function () use ($router) {
    $router->get('googlesheet', 'SpreadsheetController@masterdata');
    $router->get('oauth2callback', 'SpreadsheetController@oauth2callback');
    $router->get('appointment/{appointment_encrypted_id}', 'DoctorsApi@appointmentv3');
    //$router->get('googlesheet', 'SpreadsheetController');
});
$router->group(['prefix' => 'v1'], function () use ($router) {

    $router->get('masterdata', 'DoctorsApi@masterdata');
    $router->post('fileupload', 'DoctorsApi@fileUpload');

    $router->get('doctors/{handle}', 'DoctorsApi@addPet');
    $router->post('doctors/registerprecheck', 'DoctorsApi@registerprecheck');
    $router->post('doctors/register', 'DoctorsApi@register');
    $router->post('doctors/update', 'DoctorsApi@doctorupdate');
    $router->post('doctors/updatehandle', 'DoctorsApi@updatehandle');
    $router->get('doctors/slotdetails/{esteblishmentUserMapID}', 'DoctorsApi@slotdetails');
    $router->get('doctors/skudetails/{esteblishmentUserMapID}', 'DoctorsApi@skudetails');
    $router->post('doctors/getappointment', 'DoctorsApi@getappointment');
    $router->post('doctors/scheduleappointment', 'DoctorsApi@scheduleAppointment');
    $router->post('doctors/createappointment', 'DoctorsApi@createAppointment');

    $router->get('auth/otp/{mobileno}', 'DoctorsApi@sendOtp');
    $router->post('auth/login', 'DoctorsApi@login');

    $router->post('appointment', 'DoctorsApi@listappointment');
    $router->get('appointment/{appointment_encrypted_id}', 'DoctorsApi@appointment');
    $router->post('appointment/update', 'DoctorsApi@scheduleAppointment');
    $router->post('appointment/create', 'DoctorsApi@createAppointment'); 


    $router->get('payment/{appointment_encrypted_id}/charge', 'DoctorsApi@createpayment');
    $router->get('payment/{appointment_encrypted_id}/pay', 'DoctorsApi@pay');
    $router->post('payment/{appointment_encrypted_id}/fail', 'DoctorsApi@payfail');
    $router->post('payment/{appointment_encrypted_id}/success', 'DoctorsApi@paysuccess');
    $router->post('payment/paywebhook', 'DoctorsApi@paywebhook');

    $router->get('establishments/users/{esteblishmentUserMapID}/skus', 'DoctorsApi@skudetails');
    $router->get('establishments/users/{esteblishmentUserMapID}/slots', 'DoctorsApi@slotdetails');
    $router->get('establishments/users/{esteblishmentUserMapID}/dashboard', 'DoctorsApi@dashboard');
    $router->put('establishments/users/{esteblishmentusermapID}/token', 'DoctorsApi@updatetoken');
    $router->delete('establishments/users/{esteblishmentusermapID}', 'DoctorsApi@destroy');

    $router->get('videocall/{appointment_encrypted_id}/session/create', 'VideoCallApi@videocallsessioncreate');
    $router->get('videocall/{appointment_encrypted_id}/session/disconnect', 'VideoCallApi@videocallsessiondisconnect');
    $router->get('videocall/{appointment_encrypted_id}/signal', 'VideoCallApi@videocallsingal');
    $router->get('videocall/{appointment_encrypted_id}/test', 'VideoCallApi@videocalltest');
    $router->post('videocall/callbackUrl', 'VideoCallApi@callbackUrl');
});

$router->group(['prefix' => 'v2'], function () use ($router) {

    $router->get('masterdata', 'DoctorsApi@masterdata');
    $router->post('fileupload', 'DoctorsApi@fileUpload');

    $router->get('doctors/{handle}', 'DoctorsApi@addPet');
    $router->post('doctors/registerprecheck', 'DoctorsApi@registerprecheck');
    $router->post('doctors/register', 'DoctorsApi@register');
    $router->post('doctors/update', 'DoctorsApi@doctorupdate');
    $router->post('doctors/updatehandle', 'DoctorsApi@updatehandle');
    $router->get('doctors/slotdetails/{esteblishmentUserMapID}', 'DoctorsApi@slotdetailsv2');
    $router->get('doctors/skudetails/{esteblishmentUserMapID}', 'DoctorsApi@skudetails');
    $router->post('doctors/getappointment', 'DoctorsApi@getappointmentv2');
    $router->post('doctors/scheduleappointment', 'DoctorsApi@scheduleAppointmentv2');
    $router->post('doctors/createappointment', 'DoctorsApi@createAppointmentv2');

    $router->get('auth/otp/{mobileno}', 'DoctorsApi@sendOtp');
    $router->post('auth/login', 'DoctorsApi@login');

    $router->post('appointment', 'DoctorsApi@listappointment');
    $router->get('appointment/{appointment_encrypted_id}', 'DoctorsApi@appointmentv2');
    $router->post('appointment/update', 'DoctorsApi@scheduleAppointmentv2');
    $router->post('appointment/create', 'DoctorsApi@createAppointmentv2');


    $router->get('payment/{appointment_encrypted_id}/charge', 'DoctorsApi@createpayment');
    $router->get('payment/{appointment_encrypted_id}/pay', 'DoctorsApi@payv2');
    $router->post('payment/{appointment_encrypted_id}/fail', 'DoctorsApi@payfailv2');
    $router->post('payment/{appointment_encrypted_id}/success', 'DoctorsApi@paysuccessv2');

    $router->get('establishments/users/{esteblishmentUserMapID}/skus', 'DoctorsApi@skudetails');
    $router->get('establishments/users/{esteblishmentUserMapID}/slots', 'DoctorsApi@slotdetailsv2');
    $router->get('establishments/users/{esteblishmentUserMapID}/dashboard', 'DoctorsApi@dashboard');
    $router->delete('establishments/users/{esteblishmentusermapID}', 'DoctorsApi@destroy');

    $router->get('videocall/{appointment_encrypted_id}/session/create', 'VideoCallApi@videocallsessioncreate');
    $router->get('videocall/{appointment_encrypted_id}/session/disconnect', 'VideoCallApi@videocallsessiondisconnect');
    $router->get('videocall/{appointment_encrypted_id}/signal', 'VideoCallApi@videocallsingal');
    $router->get('videocall/{appointment_encrypted_id}/test', 'VideoCallApi@videocalltest');
    $router->post('videocall/callbackUrl', 'VideoCallApi@callbackUrl');
});

$router->get('/fire', function (Request $request) {
    $id = $request->input('id');
    event(new \App\Events\ExampleEvent($id));
    return response()->json(['status' => 'success'], 200);
});
