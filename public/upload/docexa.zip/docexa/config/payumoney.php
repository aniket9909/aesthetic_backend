<?php
return [

    'KEY' => 'MTHxR83B',

    'SALT' => 'jKt5ITcxzH',

    'TEST_MODE' => TRUE,

    'DEBUG' => FALSE
];